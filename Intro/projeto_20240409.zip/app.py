from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/contato')
def contato():
    return render_template('contato.html', tel='(86)999495137', 
                           email='rogerio.sousa@ifpi.edu.br')

@app.route('/usuario', defaults={"nome":"usuário comum"})
@app.route('/usuario/<nome>')
def usuario(nome):
    return nome

@app.route('/semestre/<int:x>')
def semestre(x):
    return "Estamos no semestre " + str(x)

@app.route('/somar/<int:x>/<int:y>')
def somar(x,y):
    dados = {'n1':x, 'n2':y, 'soma':x+y}
    return render_template('soma.html', dados=dados)


if __name__ == '__main__':
    app.run()